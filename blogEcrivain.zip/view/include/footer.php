<footer>
	<div id="index" class="jumbotron container">
		<h3>Contenus</h3>
		<div class="row">
	     	<ul>
	        	<li><a class="indexLink" href="index.php">Acceuil</a></li>
	        	<li><a class="indexLink" href="index.php?action=biography">Ma biographie</a></li>    
	        	<li><a class="indexLink" href="index.php?action=genesys">La génèse du projet</a></li>
	        	<li><a class="indexLink" href="index.php?action=allArticles">Tous les articles</a></li>
	        </ul>
    	</div>
    	<div id="credit" class="row">
    			<p>Site réalisé par Antoine Libert - Tous droit réservés - 2018</p>
    	</div>
    </div> 
</footer>