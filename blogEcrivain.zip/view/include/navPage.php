<article id="navPage" class="jumbotron">
    <h3>Autres contenus</h3>
    <ul>
	    <li><a class="indexLink" href="index.php?action=biography">Ma biographie</a></li>    
	    <li><a class="indexLink" href="index.php?action=genesys">La génèse du projet</a></li>
	    <li><a class="indexLink" href="index.php?action=allArticles">Tous les articles</a></li>
    </ul>
</article>  