<article id="book" class="jumbotron">
    <h3>Précommandez mon livre !!!</h3>
    <p>Vous pouvez d'or et déjà commander mon livre <strong>Billet simple pour l'Alaska.</strong></p>
	<div id="logoBox">
	    <a href="https://www.amazon.fr/"><img src="public/pictures/amazon-logo.jpg" alt="logo amazon"></a>
	    <a href="https://www.amazon.fr/ebooks-kindle/b?ie=UTF8&node=695398031"><img src="public/pictures/kindle-logo.png" alt="logo kindle"></a>
	    <a href="https://www.fnac.com/"><img src="public/pictures/logo-fnac.jpg" alt="logo fnac"></a>
	</div>
</article>